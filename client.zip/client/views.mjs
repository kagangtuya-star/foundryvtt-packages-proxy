/**
 * FVTT 下载改进 - 改进版 views.mjs
 * 
 * 此文件是 FoundryVTT v14 的 views.mjs 的改进版本，添加了：
 * - GitHub/GitLab 下载代理支持
 * - 手动配置代理列表
 * 
 * 原始路径: App/resources/app/dist/packages/views.mjs
 * 使用方法: 复制此文件覆盖原始文件
 */

import{isNewerVersion}from"../../common/utils/helpers.mjs";import{PACKAGE_AVAILABILITY_CODES}from"../../common/constants.mjs";import{World,System,Module,PACKAGE_TYPE_MAPPING}from"./_module.mjs";import PreviewCompatibility from"./preview-compatibility.mjs";import{ReleaseData}from"../../common/config.mjs";import ProgressEmitter from"../components/progress-emitter.mjs";

// ╔═══════════════════════════════════════════════════════════════════════════╗
// ║                        手动配置区域 - 请在此处修改                           ║
// ╚═══════════════════════════════════════════════════════════════════════════╝

const GITHUB_PROXIES=[
    "https://down.fvttsora.top/",
    "https://fvtt-download-cdn.aivu.top/proxy/github/",
    "https://gh-proxy.com/",
    "https://ghproxy.net/",
    "https://mirror.ghproxy.com/",
    "https://ghps.cc/"
];

const GITLAB_PROXIES=[
    "https://down.fvttsora.top/",
    "https://fvtt-download-cdn.aivu.top/proxy/gitlab/"
];

// ╔═══════════════════════════════════════════════════════════════════════════╗
// ║                           配置区域结束                                      ║
// ╚═══════════════════════════════════════════════════════════════════════════╝

const GITHUB_DOMAINS=[
    "github.com",
    "raw.githubusercontent.com",
    "gist.github.com",
    "gist.githubusercontent.com",
    "codeload.github.com",
    "objects.githubusercontent.com"
];

const GITLAB_DOMAINS=["gitlab.com"];

function checkUrlNeedsProxy(url){
    if(!url)return{needsProxy:!1,type:null};
    try{
        const urlObj=new URL(url);
        const hostname=urlObj.hostname;
        if(hostname.includes("gh-proxy")||hostname.includes("ghproxy")||hostname.includes("ghps")||url.includes("/proxy/"))return{needsProxy:!1,type:null};
        if(GITHUB_DOMAINS.some(domain=>hostname===domain||hostname.endsWith("."+domain)))return{needsProxy:!0,type:"github"};
        if(GITLAB_DOMAINS.some(domain=>hostname===domain||hostname.endsWith("."+domain)))return{needsProxy:!0,type:"gitlab"};
    }catch(_error){}
    return{needsProxy:!1,type:null};
}

function getProxiedUrl(originalUrl){
    const{needsProxy,type}=checkUrlNeedsProxy(originalUrl);
    if(!needsProxy)return originalUrl;
    const proxies=type==="github"?GITHUB_PROXIES:GITLAB_PROXIES;
    if(proxies.length>0){
        global.logger?.info?.("[Mirror Fix] Proxying "+type+" URL: "+originalUrl);
        return proxies[0]+originalUrl;
    }
    return originalUrl;
}
export async function getPackages({type:e="system"}={}){const t=PACKAGE_TYPE_MAPPING[e];if(!t)throw new Error(`Invalid package type ${e} requested`);const{packages:r,owned:o}=await t.getRepositoryPackages();return{packages:Array.from(r.values()).map(e=>e.vend()),owned:o}}export async function getPackageFromRemoteManifest({type:e="module",manifest:t=""}={}){const r=PACKAGE_TYPE_MAPPING[e];return await r.fromRemoteManifest(t)}export async function checkPackage({type:e,id:t,manifest:r,forceSidegrade:o=!1,strict:a=!0}={}){const s=PACKAGE_TYPE_MAPPING[e];if(!s)throw new Error(`Invalid package type ${e} requested`);const n=s.get(t,{strict:!1});if(!r){if(!n.manifest)throw new Error(`The ${e} ${t} has no manifest URL provided`);r=n.manifest}const i=await s.check(r,n,{strict:a}),c=i.remote;let p;if(c&&(t||=c.id),(n||o)&&(p=await s.fromRepository(t),c&&o&&p&&c.sidegrade(c,p)),n&&p&&(!c||isNewerVersion(p.version,c.version))&&(i.trackChange=n.suggestTrackChange(p),i.trackChange&&i.error&&404===i.errorCode&&delete i.error,i.trackChange))return i;if(!c)return i;if("module"===e){i.systemCompatibility={};for(const{id:e,compatibility:t}of c.relationships?.systems??[]){const r=System.get(e,{strict:!1});r&&(i.systemCompatibility[e]={id:e,title:r.title,version:r.version,compatible:c.constructor.testDependencyCompatibility(t,r)&&!r.unavailable})}}if(i.isUpgrade||i.isDowngrade)return i;if(n){n.sidegrade(c,p)&&(i.hasSidegraded=!0)}return i}export async function installPackage({type:e,id:t,manifest:r,force:o=!1}){const a=PACKAGE_TYPE_MAPPING[e];if("world"===e||!a)throw new Error(`Invalid package type ${e} requested`);if(!r)throw new Error("A manifest URL must be provided");const s=await checkPackage({type:e,id:t,manifest:r,forceSidegrade:!0}),n=s.remote;if(!n){const t=[`Unable to load valid ${e} manifest data from "${r}"`,s.error].filterJoin("\n");throw new Error(t)}if(t=n.id,s.isDowngrade&&!o)throw new Error(`You are currently using a more recent version of ${e} ${n.title} and may not downgrade to an older version`);const i=n.availability,c=PACKAGE_AVAILABILITY_CODES;if(!o){if(i===c.REQUIRES_CORE_DOWNGRADE)throw new Error(`${e} ${t} version ${n.version} requires an older version of the Foundry Virtual Tabletop software: ${n.compatibility.maximum} or older`);if([c.REQUIRES_CORE_UPGRADE_STABLE,c.REQUIRES_CORE_UPGRADE_UNSTABLE,c.REQUIRES_CORE_UPGRADE_UNKNOWN].includes(i))throw new Error(`${e} ${t} version ${n.version} requires a more modern version of the Foundry Virtual Tabletop software: ${n.compatibility.minimum} or newer`)}let p,l=n.download;if(n.protected){if(p=await a.getProtectedDownloadURL({type:e,id:t,version:n.version}),"error"===p.status)throw new Error(p.message);l=p.download}if(!l)throw new Error(`The ${n.title} ${e} does not provide a download URL that can be installed`);const{needsProxy:E}=checkUrlNeedsProxy(l);E&&(global.logger.info("[Mirror Fix] Intercepted Download URL: "+l),l=getProxiedUrl(l),global.logger.info("[Mirror Fix] Using Mirror URL: "+l));const S={};return new Promise(async(o,s)=>{let n;const{ACTIONS:i,STEPS:c}=CONST.SETUP_PACKAGE_PROGRESS,d=new ProgressEmitter(i.INSTALL_PKG,null,1,{type:e,id:r,title:t}),m={[c.DOWNLOAD]:"Downloading package",[c.INSTALL]:"Installing package"};try{const e=await a.install(t,r,l,p,{onFetched:()=>o(S),onProgress:(e,t,r)=>{e!==n&&(d.nextStep(e,r,{message:`SETUP.PackageProgress${e.titleCase()}`}),n=e),d.emit(t,{log:m[e]})},onError:(e,t)=>{if(e===c.DOWNLOAD)return s(t);d.error(t)}});if(!e)return d.error(new Error("PACKAGE.InstallFailed"),{context:{packageWarnings:{[t]:packages.warnings.toJSON()[t]}}}),void s(new Error("PACKAGE.InstallFailed"));d.complete({context:{pkg:e.vend()}})}catch(e){d.error(e),s(e)}})}export async function resetPackages(){return Module.resetPackages(),System.resetPackages(),World.resetPackages(),{message:"Reset package cache for all package types"}}export async function uninstallPackage({type:e,id:t}){const r=PACKAGE_TYPE_MAPPING[e];if(!r)throw new Error(`Invalid package type ${e} requested`);const o=r.uninstall(t);return o.uninstalled=!0,o}export async function lockPackage({type:e,id:t,shouldLock:r}){const o=PACKAGE_TYPE_MAPPING[e];if(!o)throw new Error(`Invalid package type ${e} requested`);return o.get(t,{strict:!1}).lock(r),{message:`Locked package ${t}`}}export async function handlePreviewCompatibility({release:e}){const t=new PreviewCompatibility(new ReleaseData(e));return await t.evaluate(),t.vend()}export function handleCreateBackups({backups:e}){const{packages:t,express:r}=global,{ACTIONS:o,STEPS:a}=CONST.SETUP_PACKAGE_PROGRESS;return t.backups.createBackups(e).catch(e=>{r.io.emit("progress",{action:o.CREATE_BACKUP,step:a.ERROR,error:e.message,stack:e.stack})}),{}}export function handleCreateSnapshot({note:e,id:t}){const{packages:r,express:o}=global,{ACTIONS:a,STEPS:s}=CONST.SETUP_PACKAGE_PROGRESS;return r.backups.createSnapshot({note:e,id:t}).catch(e=>{o.io.emit("progress",{action:a.CREATE_SNAPSHOT,steps:s.ERROR,error:e.message,stack:e.stack})}),{}}export function handleDeleteBackups({backups:e}){const{packages:t,express:r}=global,{ACTIONS:o,STEPS:a}=CONST.SETUP_PACKAGE_PROGRESS;return t.backups.deleteBackups(e).catch(e=>{r.io.emit("progress",{action:o.DELETE_BACKUP,step:a.ERROR,error:e.message,stack:e.stack})}),{}}export function handleDeleteSnapshots({snapshots:e}){const{packages:t,express:r}=global,{ACTIONS:o,STEPS:a}=CONST.SETUP_PACKAGE_PROGRESS;return t.backups.deleteSnapshots(e).catch(e=>{r.io.emit("progress",{action:o.DELETE_SNAPSHOT,step:a.ERROR,error:e.message,stack:e.stack})}),{}}export function handleRestoreBackups({backups:e}){const{packages:t,express:r}=global,{ACTIONS:o,STEPS:a}=CONST.SETUP_PACKAGE_PROGRESS;return t.backups.restoreBackups(e).catch(e=>{r.io.emit("progress",{action:o.RESTORE_BACKUP,steps:a.ERROR,error:e.message,stack:e.stack})}),{}}export function handleRestoreSnapshot({snapshotData:e}){const{packages:t,express:r}=global,{ACTIONS:o,STEPS:a}=CONST.SETUP_PACKAGE_PROGRESS;return t.backups.restoreSnapshot(e).catch(e=>{r.io.emit("progress",{action:o.RESTORE_SNAPSHOT,steps:a.ERROR,error:e.message,stack:e.stack})}),{}}